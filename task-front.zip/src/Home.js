import React, { useState,useEffect } from 'react';

const initialFormState = {
  name: '',
  email: '',
  phone: '',
  description: '',
  role_id: '',
  profile_image: null,
};

const Home = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [touchedFields, setTouchedFields] = useState({});
  const [isFormValid, setIsFormValid] = useState(false);
  const [userData, setUserData] = useState([]);
  const [message, setMessage] = useState('');
  const [isFormSubmitting, setIsFormSubmitting] = useState(false);

  const baseUrl = 'http://localhost/task/api/';
  

  
  const fetchUserData = async () => {
    try {
      const response = await fetch(`${baseUrl}get-users`);
      const data = await response.json();
      setUserData(data);
    } catch (error) {
      console.error('Error fetching user data:', error);
    }
  };

  useEffect(() => {
    fetchUserData();
  }, []);

  const validateFile = (file) => {
    if (!file) {
      return 'Profile image is required';
    }

    const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg'];
    const maxSize = 2 * 1024 * 1024;

    if (!allowedTypes.includes(file.type)) {
      return 'Invalid file type. Please upload a Jpg,Jpeg or png file.';
    }

    if (file.size > maxSize) {
      return 'File size exceeds 2MB.';
    }

    return '';
  };

  const validateField = (name, value) => {
    switch (name) {
      case 'name':
        return value ? '' : 'Name is required';

      case 'email':
        return value ? (/^\S+@\S+\.\S+$/.test(value) ? '' : 'Invalid email address') : 'Email is required';

      case 'phone':
        return value ? (/^[6-9]\d{9}$/.test(value) ? '' : 'Invalid Indian phone number') : 'Phone is required';

      case 'role_id':
        return value ? '' : 'Role ID is required';

      case 'description':
            return value ? '' : 'Description is required';
        
       case 'profile_image':
        return validateFile(value);
        
        default:
        return '';
    }
  };

  

  const handleBlur = (name) => {
    setTouchedFields((prevTouchedFields) => ({ ...prevTouchedFields, [name]: true }));
  };

  const handleChange = (e) => {
    const { name, value, type, files } = e.target;

    if (type === 'file') {
      const file = files[0];
      setFormData((prevData) => ({
        ...prevData,
        profile_image: file,
      }));
    } else {
      setFormData((prevData) => ({
        ...prevData,
        [name]: value,
      }));
      setErrors((prevErrors) => ({
        ...prevErrors,
        [name]: touchedFields[name] ? validateField(name, value) : '',
      }));
    }

    setTouchedFields((prevTouchedFields) => ({ ...prevTouchedFields, [name]: true }));
  };
 

  const renderUserData = () => {
    return (
        <div className="table-responsive">
        <table className="table table-bordered table-striped">
          <thead>
            <tr>
              <th>Profile Image</th>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Description</th>
              <th>Role</th>
            </tr>
          </thead>
          <tbody>
            {userData?.data?.map((user) => (
              <tr key={user.id}>
                <td>
                  {user.profile_image && (
                    <img
                      src={user.profile_image}
                      alt={`Profile of ${user.name}`}
                      style={{ width: '50px', height: '50px' }}
                    />
                  )}
                </td>
                <td>{user.name}</td>
                <td>{user.email}</td>
                <td>{user.phone}</td>
                <td>{user.description}</td>
                <td>{user.get_user_role.name}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  if(message){
    setTimeout(() => {
        setMessage('');
      }, 3000);
  }
  

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsFormSubmitting(true);
  
    
    const newTouchedFields = { ...touchedFields };
    Object.keys(initialFormState).forEach((key) => {
      newTouchedFields[key] = true;
    });
    setTouchedFields(newTouchedFields);
  
   
    const newErrors = {};
    Object.entries(formData).forEach(([name, value]) => {
      newErrors[name] = validateField(name, value);
    });
  
    setErrors(newErrors);
    const formIsValid = Object.values(newErrors).every((error) => !error);
    setIsFormValid(formIsValid);
  
    try {
      if (formIsValid) {
        const formDataObj = new FormData();
  
       
        Object.entries(formData).forEach(([key, value]) => {
          formDataObj.append(key, value);
        });
  
        const response = await fetch(`${baseUrl}post-user`, {
          method: 'POST',
          body: formDataObj,
        });
  
        if (!response.ok) {
          throw new Error('Failed to submit the form');
        }
  
        const responseJson = await response.json();
        setMessage(responseJson.message);
  
        if (responseJson.status) {
          fetchUserData();
        }
        console.log(responseJson.message);
      } else {
        console.log('Form is not valid. Please check errors.');
      }
    } catch (error) {
      console.error(error);
      alert('An error occurred while submitting the form');
    } finally {
      setIsFormSubmitting(false);
    }
  };
  

  return (
    
    <div className="container border">
        <h4 className='mb-4'>User Form</h4>
      {message && <p className="alert alert-success">{message}</p>}
      <form encType='multipart/form-data' onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">Name:</label>
          <input
            type="text"
            className={`form-control ${touchedFields.name && errors.name ? 'is-invalid' : ''}`}
            name="name"
            value={formData.name}
            onChange={handleChange}
            onBlur={() => handleBlur('name')}
          />
          {touchedFields.name && errors.name && <div className="invalid-feedback">{errors.name}</div>}
        </div>

        <div className="mb-3">
          <label className="form-label">Email:</label>
          <input
            type="text"
            className={`form-control ${touchedFields.email && errors.email ? 'is-invalid' : ''}`}
            name="email"
            value={formData.email}
            onChange={handleChange}
            onBlur={() => handleBlur('email')}
          />
          {touchedFields.email && errors.email && <div className="invalid-feedback">{errors.email}</div>}
        </div>

        <div className="mb-3">
          <label className="form-label">Phone:</label>
          <input
            type="text"
            className={`form-control ${touchedFields.phone && errors.phone ? 'is-invalid' : ''}`}
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            onBlur={() => handleBlur('phone')}
          />
          {touchedFields.phone && errors.phone && <div className="invalid-feedback">{errors.phone}</div>}
        </div>

        <div className="mb-3">
          <label className="form-label">Description:</label>
          <textarea
            className={`form-control ${touchedFields.description && errors.description ? 'is-invalid' : ''}`}
            name="description"
            value={formData.description}
            onChange={handleChange}
            onBlur={() => handleBlur('description')}
          />
          {touchedFields.description && errors.description && <div className="invalid-feedback">{errors.description}</div>}
        </div>

        <div className="mb-3">
          <label className="form-label">Role:</label>
          <select
            className={`form-select ${touchedFields.role_id && errors.role_id ? 'is-invalid' : ''}`}
            name="role_id"
            value={formData.role_id}
            onChange={handleChange}
            onBlur={() => handleBlur('role_id')}
          >
            <option value="">Select Role</option>
            <option value="1">Admin</option>
            <option value="2">Staff</option>
            <option value="3">Manager</option>
            <option value="4">Customer</option>
          </select>
          {touchedFields.role_id && errors.role_id && <div className="invalid-feedback">{errors.role_id}</div>}
        </div>

        <div className="mb-3">
          <label className="form-label">Profile Image:</label>
          <input
            type="file"
            className={`form-control ${touchedFields.profile_image && errors.profile_image ? 'is-invalid' : ''}`}
            name="profile_image"
            onChange={handleChange}
            onBlur={() => handleBlur('profile_image')}
          />
          {touchedFields.profile_image && errors.profile_image && <div className="invalid-feedback">{errors.profile_image}</div>}
        </div>

        <button type="submit" className="btn btn-primary mb-3" disabled={isFormSubmitting}>
            {isFormSubmitting ? 'Submitting...' : 'Submit'}
        </button>
      </form>

      {userData.data ? (
        userData.data.length > 0 ? (
            <div>
            <h4 className='mt-5'>User List</h4>
            {renderUserData()}
            </div>
        ) : (
            'No users found.'
        )
        ) : (
        'Loading...'
        )}

    </div>
  );
};

export default Home;