<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use \App\Models\User;

class UserController extends Controller
{
    public function getUsers(){
        
        $rows = User::with('getUserRole')->orderBy('id','desc')->get();

        return response()->json(['status' => true, "message" => "Successfully Fetch","data" =>$rows]);
    }


    public function postUser(Request $request)
    {
        
        $validator = Validator::make($request->all() , [

        "name" => "required|max:50",
        "email" => "required|email|unique:users,email",
        "profile_image" => $request->hasFile('profile_image') ? "required|mimes:jpg,jpeg,png" : "", 
        "description" => "required", 
        "role_id" => "required",
        'phone' => 'required|digits:10',
        
        ]);
        if($validator->fails())
        {
            return response()->json(["message" =>  $this->validationHandle($validator->errors()) , "status" => false,"data" => []]);
        }


        $user = new User;
        $user->name = $request->name;
        $user->email = $request->email;
        $user->description = $request->description;
        $user->phone = $request->phone;
        $user->role_id = $request->role_id;

        if($request->hasFile('profile_image')){
            $user->profile_image = $this->upload($request->file('profile_image') , 'users');
        } 

        $user->save();

        $response = [
            'status' => true, "message" => "User detail store successfully.", "data" => []
        ];

        return response()->json($response);
    }

    function upload($fileName,$path="uploads")
    {
            $file = $fileName;
            $destinationPath = 'storage/uploads/'.$path;
            $exist = is_dir($destinationPath);
           
            if(!$exist) {
                mkdir("$destinationPath");
                chmod("$destinationPath", 0755);
            }

            $extension = $file->getClientOriginalExtension();
            $fileName = strtotime(now()).'-'.rand(11111,99999).'.'.$extension;
            $file->move($destinationPath, $fileName);
            return $fileName;
    }
}
